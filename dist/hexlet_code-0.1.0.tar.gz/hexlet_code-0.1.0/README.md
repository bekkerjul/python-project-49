### Hexlet tests and linter status:
[![Actions Status](https://github.com/bekkerjul/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bekkerjul/python-project-49/actions)
<a href="https://codeclimate.com/github/bekkerjul/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c595224a6a3a4ae11716/maintainability" /></a>
<a href="https://asciinema.org/a/Eq9UiWfr6l7hUQoVQmx2k8c1O" target="_blank"><img src="https://asciinema.org/a/Eq9UiWfr6l7hUQoVQmx2k8c1O.svg" /></a>
<a href="https://asciinema.org/a/2dBVaN502yqJQYJnBoPdkeCNi" target="_blank"><img src="https://asciinema.org/a/2dBVaN502yqJQYJnBoPdkeCNi.svg" /></a>
<a href="https://asciinema.org/a/o2nK1aweVotwthXvhqAIC1vYE" target="_blank"><img src="https://asciinema.org/a/o2nK1aweVotwthXvhqAIC1vYE.svg" /></a>
