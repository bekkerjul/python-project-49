### Hexlet tests and linter status:
[![Actions Status](https://github.com/bekkerjul/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bekkerjul/python-project-49/actions)
<a href="https://codeclimate.com/github/bekkerjul/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c595224a6a3a4ae11716/maintainability" /></a>
