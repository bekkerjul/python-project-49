from random import randint
from brain_games import welcome_user


def is_even():
    num = randint(0, 10000000)
    return 'yes' if num % 2 == 0 else 'no'
def main():
    welcome_user()
    points = 0
    print('Answer "yes" if the number is even, otherwise answer "no".')

    while points < 3:
        print(f'Question: {num}')
        answer = input('Your answer: ')
        right_answer = is_even()
        if answer == right_answer:
            print('Correct!')
            points += 1
        else:
            print(f"'{answer}' is wrong answer ;(. Correct answer was 'yes'.\nLet's try again, {name}!")
            points = 0

    print('Congratulations, {name}!')
