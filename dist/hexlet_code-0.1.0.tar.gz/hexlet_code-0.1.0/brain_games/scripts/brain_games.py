#!/usr/bin/env python3
from ..cly import welcome_user


def main():
    print('Welcome to the Brain Games!')


main()
welcome_user()
